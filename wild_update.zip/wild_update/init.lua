local modpath = minetest.get_modpath("wild_update")

-- Load files

dofile(modpath .. "/blocks.lua")
--dofile(modpath .. "/mobs.lua")--
--dofile(modpath .. "/item.lua")--