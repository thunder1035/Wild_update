# The Wild Update
this mod is the wild update for mineclone 2 and 5, features all the new thing which minecraft 1.19 has in it.

this will have -
- Swamps
- Frogs
- Tadpoles
- Fireflies
- Mangrove swamps
- Mangrove full set + roots
- Chest Boats
- Deep Dark
- All sculk Blocks
- Warden
- Ancient cities (not implemented yet)﻿

https://www.planetminecraft.com/mod/the-wild-mod-fabric-5373520/

## Version
1.0

## License
AGNU 3.0 License.
